<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zu" sourcelanguage="en_US">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>default</name>
    <message>
        <source>192.168.1.100:8096 or https://example.com/jellyfin</source>
        <translation>192.168.1.100:8096 noma https://example.com/jellyfin</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Esula</translation>
    </message>
    <message>
        <source>Connect to Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ends at %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter Configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Favorite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Loading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Login attempt failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please sign in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server not found, is it online?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Shuffle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sign In</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Submit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Watched</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>My Media</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Continue Watching</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Next Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Latest in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enter a value...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sort Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Date Added</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Release Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sort Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Descending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Genres</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Director</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Server</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name></name>
    <message>
        <source>Save Credentials?</source>
        <translation>Gcina imininingwane?</translation>
    </message>
</context>
</TS>
