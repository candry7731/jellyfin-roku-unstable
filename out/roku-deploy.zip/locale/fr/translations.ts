<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr" sourcelanguage="en_US">
<defaultcodec>UTF-8</defaultcodec>
<context>
    <name>default</name>
    <message>
        <source>192.168.1.100:8096 or https://example.com/jellyfin</source>
        <translation>Valeur par défaut : 192.168.1.100:8096 ou https://example.com/jellyfin</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Annuler</translation>
    </message>
    <message>
        <source>Connect to Server</source>
        <translation>Se connecter au serveur</translation>
    </message>
    <message>
        <source>Ends at %1</source>
        <translation>Se termine à %1</translation>
    </message>
    <message>
        <source>Enter Configuration</source>
        <translation>Entrer la configuration</translation>
    </message>
    <message>
        <source>Favorite</source>
        <translation>Favoris</translation>
    </message>
    <message>
        <source>Loading...</source>
        <translation>Chargement...…</translation>
    </message>
    <message>
        <source>Login attempt failed.</source>
        <translation>La tentative de connexion à échoué...</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Options</source>
        <translation>Options</translation>
    </message>
    <message>
        <source>Play</source>
        <translation>Démarrer</translation>
    </message>
    <message>
        <source>Please sign in</source>
        <translation>Se connecter</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Rechercher</translation>
    </message>
    <message>
        <source>Server not found, is it online?</source>
        <translation>Serveur non trouvé, est-il connecté à Internet ?</translation>
    </message>
    <message>
        <source>Shuffle</source>
        <translation>Aléatoire</translation>
    </message>
    <message>
        <source>Sign In</source>
        <translation>Se connecter</translation>
    </message>
    <message>
        <source>Submit</source>
        <translation>Valider</translation>
    </message>
    <message>
        <source>Watched</source>
        <translation>Vu</translation>
    </message>
    <message>
        <source>Change Server</source>
        <translation>Changer de serveur</translation>
    </message>
    <message>
        <source>Sign Out</source>
        <translation>Se déconnecter</translation>
    </message>
    <message>
        <source>Add User</source>
        <translation>Ajouter un utilisateur</translation>
    </message>
    <message>
        <source>Profile</source>
        <translation>Profil</translation>
    </message>
    <message>
        <source>My Media</source>
        <translation>Mes Médias</translation>
    </message>
    <message>
        <source>Continue Watching</source>
        <translation>Reprendre le visionnage</translation>
    </message>
    <message>
        <source>Next Up</source>
        <translation>Suivant</translation>
    </message>
    <message>
        <source>Latest in</source>
        <translation>Dernière</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>Accueil</translation>
    </message>
    <message>
        <source>Enter a value...</source>
        <translation>Entrer une valeur…</translation>
    </message>
    <message>
        <source>Sort Field</source>
        <translation>Trier par</translation>
    </message>
    <message>
        <source>Date Added</source>
        <translation>Date d&apos;ajout</translation>
    </message>
    <message>
        <source>Release Date</source>
        <translation>Date de sortie</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Sort Order</source>
        <translation>Trie par ordre</translation>
    </message>
    <message>
        <source>Descending</source>
        <translation>Décroissant</translation>
    </message>
    <message>
        <source>Ascending</source>
        <translation>Croissant</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Mot de passe</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Identifiant</translation>
    </message>
    <message>
        <source>Genres</source>
        <translation>Types</translation>
    </message>
    <message>
        <source>Director</source>
        <translation>Direction</translation>
    </message>
    <message>
        <source>Video</source>
        <translation>Vidéos</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation>Musiques</translation>
    </message>
    <message>
        <source>Server</source>
        <translation>Serveur</translation>
    </message>
</context>
<context>
    <name></name>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Impossible de charger les données de la chaîne depuis le serveur</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Erreur lors du chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Impossible de charger les données de la chaîne à partir du serveur</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Erreur lors du chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des données de cet élément sur le serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur lors de la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 contient aucun élément</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Impossible de charger les données de la chaîne depuis le serveur</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Erreur lors du chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des données de cet élément à partir du serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur pendant la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtre</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Tri</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Vue</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Durée</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Date de sortie</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Nombre de lectures</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Classification parentale</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Date de lecture</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Date d&apos;ajout</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Notation critiques</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>Notation IMDb</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Nom</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 ne contient aucun élément</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Impossible de charger les données de la chaîne depuis le serveur</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Erreur lors du chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des données de cet élément sur le serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur lors de la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>En direct</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Fini</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended  (e.g.  Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Fini à</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g.  Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Débutera</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g.  Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Débutera à</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g.  Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Débuté</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g.  Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Débuté à</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g.  Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samedi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Vendredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Jeudi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mercredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Mardi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Lundi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Dimanche</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>demain</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>hier</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>aujourd&apos;hui</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtre</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Tri</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Vue</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Durée</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Date de sortie</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Nombre de lectures</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Classification parentale</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Date de lecture</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Date d&apos;ajout</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Notation critiques</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>Notation IMDb</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Nom</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 ne contient aucun élément</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Impossible de charger les données de la chaîne depuis le serveur</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Erreur lors du chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des données de cet élément sur le serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur durant la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur de récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>Guide des chaines</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Chaines</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Relancer</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Chaînes</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samedi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Vendredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Jeudi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mercredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Mardi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des informations pour cet élément sur le serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur pendant la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des informations pour cet élément sur le serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Le contenu demandé n&apos;existe pas sur le serveur</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Non trouvé</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Connexion au serveur</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>Guide des chaînes</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Chaînes</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Rediffusion</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>En direct</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Terminé à</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended  (e.g.  Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Terminé à</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g.  Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Débutera</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g.  Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Débute à</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g.  Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Débuté</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g.  Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Débuté à</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g.  Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samedi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Vendredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Jeudi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mercredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Mardi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Lundi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Dimanche</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>demain</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>hier</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Nombre de lectures</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Classification parentale</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Date de lecture</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Notations critiques</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 ne contient aucun élément</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur pendant la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>aujourd&apos;hui</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtrer</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Trier</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Vue</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Durée</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Date de sortie</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Date d&apos;ajout</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>Notation IMDb</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Nom</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Impossible de charger les données de la chaîne depuis le serveur</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Erreur lors du chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite durant la lecture de cet élément</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite durant la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Le contenu demandé n&apos;existe pas sur le serveur</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Non trouvé</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Connexion au serveur</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>Guide des chaînes</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Chaînes</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Rediffusion</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>En direct</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Terminé à</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended  (e.g.  Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Terminé à</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g.  Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Débutera</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g.  Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Débutera à</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g.  Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Débuté</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g.  Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Débuté à</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g.  Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samedi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Vendredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Jeudi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mercredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Mardi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Lundi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Dimanche</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>demain</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>hier</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>aujourd&apos;hui</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtrer</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Trier</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Vue</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Durée</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Date de sortie</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Nombre de lectures</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Classification parentale</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Date de lecture</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Date d&apos;ajout</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Note des critiques</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>Note IMDb</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Nom</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 ne contient aucun élément</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Impossible de charger les données de la chaîne depuis le serveur</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Erreur lors du chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite durant la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des informations pour cet élément sur le serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur pendant la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite durant la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des informations pour cet élément sur le serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur pendant la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...ou entrez manuellement l&apos;adresse du serveur :</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Choisissiez un serveur Jellyfin depuis le réseau local</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Entrer le nom du serveur ou l&apos;adresse IP</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Le contenu demandé n&apos;existe pas sur le serveur</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Non trouvé</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Connexion au serveur</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>Guide des chaînes</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Chaînes</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Rediffusion</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>En direct</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Terminé à</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended  (e.g.  Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Terminé à</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g.  Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Débutera</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g.  Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Débutera à</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g.  Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Débuté</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g.  Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Débuté à</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g.  Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samedi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Vendredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Jeudi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mercredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Mardi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Lundi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Dimanche</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>demain</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>hier</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>aujourd&apos;hui</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtrer</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Trier</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Vue</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Durée</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Date de sortie</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Nombre de lectures</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Classification parentale</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Date de lecture</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Date d&apos;ajout</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Note des critiques</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>Note IMDb</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Nom</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 ne contient aucun élément</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Impossible de charger les données de la chaîne depuis le serveur</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Erreur lors du chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Choisissiez un serveur Jellyfin depuis le réseau local</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Entrer le nom du serveur ou l&apos;adresse IP</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Le contenu demandé n&apos;existe pas sur le serveur</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Non trouvé</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Connexion au serveur</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>Guide des chaînes</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Chaînes</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Rediffusion</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>En direct</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Terminé à</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended  (e.g.  Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Terminé à</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g.  Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Débutera</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g.  Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Débutera à</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g.  Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Débuté</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g.  Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Débuté à</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g.  Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samedi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Vendredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Jeudi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mercredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Mardi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Lundi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Dimanche</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>demain</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>hier</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>aujourd&apos;hui</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtrer</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Trier</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Vue</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Durée</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Date de sortie</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Nombre de lectures</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Classification parentale</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Date de lecture</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Date d&apos;ajout</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Note des critiques</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>Note IMDb</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Nom</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 ne contient aucun élément</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Impossible de charger les données de la chaîne depuis le serveur</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Erreur lors du chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données de canal</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des données de cet élément à partir du serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur lors de la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...ou entrez l&apos;URL du serveur manuellement&#xa0;:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Note des critiques</translation>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>En ce moment</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.  Server did not provide required transcoding data.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément. Le serveur n&apos;a pas fourni les données de transcodage nécessaires.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Impossible de retrouver les informations de lecture</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...ou entrez l&apos;URL du serveur manuellement&#xa0;:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Choisissiez un serveur Jellyfin depuis le réseau local</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Entrer le nom ou l&apos;adresse IP du serveur</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Le contenu demandé n&apos;existe pas sur le serveur</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Non trouvé</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Connexion au serveur en cours</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>Guide des chaînes</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Chaînes</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Rediffusion</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>En direct</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Terminé</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended  (e.g.  Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Terminé à</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g.  Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Débutera</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g.  Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Débutera à</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g.  Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Débuté</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g.  Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Débuté à</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g.  Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samedi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Vendredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Jeudi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mercredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Mardi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Lundi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Dimanche</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>demain</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>hier</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>aujourd&apos;hui</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtrer</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Trier</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Vue</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Durée</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Date de sortie</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Nombre de lectures</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Classification parentale</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Date de lecture</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Date d&apos;ajout</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Note des critiques</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>Note IMDb</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Nom</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 ne contient aucun élément</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Impossible de charger les données de la chaîne depuis le serveur</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Erreur lors du chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des données de cet élément à partir du serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur lors de la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Supprimer les valeurs enregistrées</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Enregistrer les identifiants ?</translation>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Répéter</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Direct</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Fini à</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended  (e.g.  Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Termine à</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g.  Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Commence à</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g.  Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>A débuté</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g.  Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Commencé à</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g.  Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samedi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Vendredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Jeudi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mercredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Mardi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Lundi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>dimanche</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>demain</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>hier</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>aujourd&apos;hui</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtre</translation>
    </message>
    <message>
        <comment>Title of Tab for switching &quot;views&quot; when looking at a library</comment>
        <source>TAB_VIEW</source>
        <translation>Voir</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Durée</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Date de sortie</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Nombre de lectures</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Évaluation parentale</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Date de lecture</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>date d&apos;ajout</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Note des critiques</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>Classement IMDb</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Nom</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 ne contient aucun élément</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Impossible de charger les données de canal à partir du serveur</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Erreur lors du chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données du canal</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des données de cet élément à partir du serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur lors de la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Maintenant</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Enregistrer les identifiants ?</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.  Server did not provide required transcoding data.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.  Le serveur n&apos;a pas fourni les données de transcodage nécessaires.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Impossible de retrouver les informations de lecture</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...ou entrez l&apos;URL du serveur manuellement&#xa0;:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Choisissiez un serveur Jellyfin depuis le réseau local</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Entrer le nom ou l&apos;adresse IP du serveur</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Le contenu demandé n&apos;existe pas sur le serveur</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Non trouvé</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Connexion au serveur en cours</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Annuler l&apos;enregistrement des séries</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Annuler l&apos;enregistrement</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Enregistrer une série</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Voir la chaîne</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>Guide des chaînes</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Chaînes</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Débutera</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g.  Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Trier</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Supprimer les valeurs enregistrées</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des données de cet élément à partir du serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur lors de la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation>Maintenant</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Supprimer les valeurs enregistrées</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Enregistrer les identifiants ?</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Sauvegarder les informations d&apos;identification ?</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Supprimer les valeurs enregistrées</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Âge</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Décès</translation>
    </message>
    <message>
        <source>Born</source>
        <translation>Naissance</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtre</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Trier</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Durée</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Date de sortie</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Nombre de lecture</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Date de lecture</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Date d&apos;ajout</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Note des critiques</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>Classement IMDb</translation>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Nom</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 ne contient aucun élément</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Impossible de charger les données de la chaîne à partir du serveur</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Erreur lors du chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des données de cet élément à partir du serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation type="unfinished">Erreur pendant la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation type="unfinished">Erreur pendant la récupération du contenant</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>On Now</source>
        <translation type="unfinished">Actifs actuellement</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Supprimer les valeurs enregistrées</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Enregistrer les identifiants ?</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.  Server did not provide required transcoding data.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.  Le serveur n&apos;a pas fourni les données de transcodage nécessaires.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Impossible de récupérer les informations de lecture</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...ou entrez l&apos;URL du serveur manuellement&#xa0;:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Choisissiez un serveur Jellyfin depuis le réseau local</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Entrer le nom ou l&apos;adresse IP du serveur</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Le contenu demandé n&apos;existe pas sur le serveur</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Non trouvé</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Connexion au serveur en cours</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Annuler l&apos;enregistrement</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Enregistrer une série</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Voir la chaîne</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>Guide des chaînes</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Chaînes</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Rediffusion</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Direct</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Terminé à</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended  (e.g.  Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Termine à</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g.  Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Débutera</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g.  Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Commencé à</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g.  Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samedi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Vendredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Jeudi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mercredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Mardi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Lundi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Dimanche</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>demain</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>hier</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>aujourd&apos;hui</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Classification parentale</translation>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur lors de la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <comment>Name or Title field of media item</comment>
        <source>TITLE</source>
        <translation>Nom</translation>
    </message>
    <message>
        <comment>Message displayed in Item Grid when no item to display. %1 is container type (e.g. Boxset, Collection, Folder, etc)</comment>
        <source>NO_ITEMS</source>
        <translation>%1 ne contient aucun élément</translation>
    </message>
    <message>
        <source>Unable to load Channel Data from the server</source>
        <translation>Impossible de charger les données de la chaîne à partir du serveur</translation>
    </message>
    <message>
        <source>Error loading Channel Data</source>
        <translation>Erreur lors du chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>Loading Channel Data</source>
        <translation>Chargement des données de la chaîne</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.</translation>
        <extracomment>Dialog detail when error occurs during playback</extracomment>
    </message>
    <message>
        <source>There was an error retrieving the data for this item from the server.</source>
        <translation>Une erreur s&apos;est produite lors de la récupération des données de cet élément à partir du serveur.</translation>
        <extracomment>Dialog detail when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Error During Playback</source>
        <translation>Erreur lors de la lecture</translation>
        <extracomment>Dialog title when error occurs during playback</extracomment>
    </message>
    <message>
        <source>Error Retrieving Content</source>
        <translation>Erreur lors de la récupération du contenu</translation>
        <extracomment>Dialog title when unable to load Content from Server</extracomment>
    </message>
    <message>
        <source>Press &apos;OK&apos; to Close</source>
        <translation>Appuyer sur &quot;OK&quot; pour fermer</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation type="unfinished">Actifs actuellement</translation>
    </message>
    <message>
        <source>Died</source>
        <translation>Mort</translation>
    </message>
    <message>
        <source>Record</source>
        <translation>Enregistrer</translation>
    </message>
    <message>
        <source>TV Guide</source>
        <translation>Guide TV</translation>
        <extracomment>Menu option for showing Live TV Guide / Schedule</extracomment>
    </message>
    <message>
        <source>Channels</source>
        <translation>Chaînes</translation>
        <extracomment>Menu option for showing Live TV Channel List</extracomment>
    </message>
    <message>
        <source>Repeat</source>
        <translation>Repeter</translation>
        <extracomment>If TV Shows has previously been broadcasted</extracomment>
    </message>
    <message>
        <source>Live</source>
        <translation>Direct</translation>
        <extracomment>If TV Show is being broadcast live (not pre-recorded)</extracomment>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Supprimer les informations enregistrées</translation>
    </message>
    <message>
        <source>Playback</source>
        <translation>Relecture</translation>
        <extracomment>Title for Playback section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Enregistrer les informations d&apos;identification ?</translation>
    </message>
    <message>
        <source>Options for Jellyfin&apos;s screensaver.</source>
        <translation>Options de l&apos;écran de veille Jellyfin.</translation>
        <extracomment>Description for Screensaver user settings.</extracomment>
    </message>
    <message>
        <source>Screensaver</source>
        <translation>Écran de veille</translation>
    </message>
    <message>
        <source>If enabled, images for unwatched episodes will be blurred.</source>
        <translation type="unfinished">Si actif, les images des épisodes non visualisés seront floutés.</translation>
    </message>
    <message>
        <source>Blur Unwatched Episodes</source>
        <translation type="unfinished">Flouter les épisodes non visualisés</translation>
        <extracomment>Option Title in user setting screen</extracomment>
    </message>
    <message>
        <source>Shows</source>
        <translation>Séries</translation>
    </message>
    <message>
        <source>Studios</source>
        <translation>Studios</translation>
    </message>
    <message>
        <source>Networks</source>
        <translation>Réseaux</translation>
    </message>
    <message>
        <source>There was an error authenticating via Quick Connect.</source>
        <translation type="unfinished">Une erreur est survenue lors de l&apos;authentification par connexion rapide.</translation>
    </message>
    <message>
        <source>(Dialog will close automatically)</source>
        <translation type="unfinished">(La fenêtre se fermera automatiquement)</translation>
    </message>
    <message>
        <source>Here is your Quick Connect code:</source>
        <translation>Voici votre code de connexion rapide&#xa0;:</translation>
    </message>
    <message>
        <source>Quick Connect</source>
        <translation>Connexion rapide</translation>
    </message>
    <message>
        <source>%1 of %2</source>
        <translation>%1 sur %2</translation>
        <extracomment>Item position and count.  %1 = current item.  %2 = total number of items</extracomment>
    </message>
    <message>
        <source>Go to episode</source>
        <translation>Aller à l&apos;épisode</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Episode Detail Page</extracomment>
    </message>
    <message>
        <source>Go to season</source>
        <translation>Aller à la saison</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Season Page</extracomment>
    </message>
    <message>
        <source>Go to series</source>
        <translation>Aller vers les séries</translation>
        <extracomment>Continue Watching Popup Menu - Navigate to the Series Detail Page</extracomment>
    </message>
    <message>
        <source>Set Watched</source>
        <translation>Marquer comme vu</translation>
        <extracomment>Button Text - When pressed, marks item as Warched</extracomment>
    </message>
    <message>
        <source>Set Favorite</source>
        <translation>Ajouter en favori</translation>
        <extracomment>Button Text - When pressed, sets item as Favorite</extracomment>
    </message>
    <message>
        <source>Show item count in the library, and index of selected item.</source>
        <translation>Afficher le nombre d&apos;éléments dans la médiathèque et l&apos;indice de l&apos;élément sélectionné.</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Count</source>
        <translation type="unfinished">Nombre d&apos;éléments</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Count in user setting screen.</extracomment>
    </message>
    <message>
        <source>Always show the titles below the poster images. (If disabled, title will be shown under hilighted item only)</source>
        <translation>Toujours afficher les titres sous les images d&apos;affiche. (Si désactivé, le titre sera affiché uniquement sous l&apos;élément sélectionné)</translation>
        <extracomment>Description for option in Setting Screen</extracomment>
    </message>
    <message>
        <source>Item Titles</source>
        <translation>Titre des éléments</translation>
        <extracomment>UI -&gt; Media Grid -&gt; Item Title in user setting screen.</extracomment>
    </message>
    <message>
        <source>Media Grid Options</source>
        <translation type="unfinished">Options de la grille média</translation>
    </message>
    <message>
        <source>Media Grid</source>
        <translation type="unfinished">Grille média</translation>
        <extracomment>UI -&gt; Media Grid section in user setting screen.</extracomment>
    </message>
    <message>
        <source>User Interface</source>
        <translation>Interface Graphique</translation>
        <extracomment>Title for User Interface section in user setting screen.</extracomment>
    </message>
    <message>
        <source>Disabled</source>
        <translation>Désactivé</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation>Activé</translation>
    </message>
    <message>
        <source>Support direct play of MPEG 2 content (e.g. Live TV). This will prevent transcoding of MPEG 2 content, but uses significantly more bandwidth</source>
        <translation type="unfinished">Support pour la lecture directe du contenu MPEG 2 (p. ex. TV en direct). Ceci empêchera le transcodage du contenu MPEG 2 mais utilise plus de bande passante</translation>
        <extracomment>Settings Menu - Description for option</extracomment>
    </message>
    <message>
        <source>MPEG 2 Support</source>
        <translation>Support MPEG 2</translation>
        <extracomment>Settings Menu - Title for option</extracomment>
    </message>
    <message>
        <source>Version</source>
        <translation>Version</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation>Inconnu</translation>
        <extracomment>Title for a cast member for which we have no information for</extracomment>
    </message>
    <message>
        <source>Close</source>
        <translation>Fermer</translation>
    </message>
    <message>
        <source>View Channel</source>
        <translation>Voir la chaîne</translation>
    </message>
    <message>
        <source>Starts at</source>
        <translation>Débutera à</translation>
        <extracomment>(Future Tense) For defining time when a program will start today (e.g.  Starts at 08:00) </extracomment>
    </message>
    <message>
        <source>Thursday</source>
        <translation>Jeudi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>TV Shows</source>
        <translation>Séries TV</translation>
    </message>
    <message>
        <source>On Now</source>
        <translation type="unfinished">Maintenant</translation>
    </message>
    <message>
        <source>An error was encountered while playing this item.  Server did not provide required transcoding data.</source>
        <translation>Une erreur s&apos;est produite lors de la lecture de cet élément.  Le serveur n&apos;a pas fourni les données de transcodage nécessaires.</translation>
        <extracomment>Content of message box when trying to play an item which requires transcoding, and the server did not provide transcode url</extracomment>
    </message>
    <message>
        <source>Error Getting Playback Information</source>
        <translation>Impossible de récupérer les informations de lecture</translation>
        <extracomment>Dialog Title: Received error from server when trying to get information about the selected item for playback</extracomment>
    </message>
    <message>
        <source>...or enter server URL manually:</source>
        <translation>...ou entrez l&apos;URL du serveur manuellement&#xa0;:</translation>
        <extracomment>Instructions on initial app launch when the user is asked to manually enter a server URL</extracomment>
    </message>
    <message>
        <source>Pick a Jellyfin server from the local network</source>
        <translation>Choisissiez un serveur Jellyfin depuis le réseau local</translation>
        <extracomment>Instructions on initial app launch when the user is asked to pick a server from a list</extracomment>
    </message>
    <message>
        <source>Enter the server name or ip address</source>
        <translation>Entrer le nom ou l&apos;adresse IP du serveur</translation>
        <extracomment>Title of KeyboardDialog when manually entering a server URL</extracomment>
    </message>
    <message>
        <source>The requested content does not exist on the server</source>
        <translation>Le contenu demandé n&apos;existe pas sur le serveur</translation>
        <extracomment>Content of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Not found</source>
        <translation>Non trouvé</translation>
        <extracomment>Title of message box when the requested content is not found on the server</extracomment>
    </message>
    <message>
        <source>Connecting to Server</source>
        <translation>Connexion au serveur en cours</translation>
        <extracomment>Message to display to user while client is attempting to connect to the server</extracomment>
    </message>
    <message>
        <source>Cancel Series Recording</source>
        <translation>Annuler l&apos;enregistrement des séries</translation>
    </message>
    <message>
        <source>Cancel Recording</source>
        <translation>Annuler l&apos;enregistrement</translation>
    </message>
    <message>
        <source>Record Series</source>
        <translation>Enregistrer une série</translation>
    </message>
    <message>
        <source>Ends at</source>
        <translation>Terminé</translation>
        <extracomment>(Past Tense) For defining a day and time when a program ended  (e.g.  Ended Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Ended at</source>
        <translation>Terminé à</translation>
        <extracomment>(Past Tense) For defining time when a program will ended (e.g.  Ended at 08:00) </extracomment>
    </message>
    <message>
        <source>Starts</source>
        <translation>Débutera</translation>
        <extracomment>(Future Tense) For defining a day and time when a program will start (e.g.  Starts Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started</source>
        <translation>Débuté</translation>
        <extracomment>(Past Tense) For defining a day and time when a program started (e.g.  Started Wednesday, 08:00) </extracomment>
    </message>
    <message>
        <source>Started at</source>
        <translation>Commencé à</translation>
        <extracomment>(Past Tense) For defining time when a program started today (e.g.  Started at 08:00) </extracomment>
    </message>
    <message>
        <source>Saturday</source>
        <translation>Samedi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Friday</source>
        <translation>Vendredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Wednesday</source>
        <translation>Mercredi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Tuesday</source>
        <translation>Mardi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Monday</source>
        <translation>Lundi</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>Sunday</source>
        <translation>Dimanche</translation>
        <extracomment>Day of Week</extracomment>
    </message>
    <message>
        <source>tomorrow</source>
        <translation>demain</translation>
        <extracomment>Next day</extracomment>
    </message>
    <message>
        <source>yesterday</source>
        <translation>hier</translation>
        <extracomment>Previous day</extracomment>
    </message>
    <message>
        <source>today</source>
        <translation>aujourd&apos;hui</translation>
        <extracomment>Current day</extracomment>
    </message>
    <message>
        <source>Movies</source>
        <translation>Films</translation>
    </message>
    <message>
        <source>Special Features</source>
        <translation>Bonus</translation>
        <message>
            <source>Press &apos;OK&apos; to Close</source>
            <translation>Press &apos;OK&apos; to Close</translation>
        </message>
    </message>
    <message>
        <source>More Like This</source>
        <translation>Similaires</translation>
    </message>
    <message>
        <source>Age</source>
        <translation>Âge</translation>
    </message>
    <message>
        <comment>Title of Tab for options to filter library content</comment>
        <source>TAB_FILTER</source>
        <translation>Filtre</translation>
    </message>
    <message>
        <comment>Title of Tab for options to sort library content</comment>
        <source>TAB_SORT</source>
        <translation>Trier</translation>
    </message>
    <message>
        <source>RUNTIME</source>
        <translation>Durée</translation>
    </message>
    <message>
        <source>RELEASE_DATE</source>
        <translation>Date de sortie</translation>
    </message>
    <message>
        <source>PLAY_COUNT</source>
        <translation>Nombre de lecture</translation>
    </message>
    <message>
        <source>OFFICIAL_RATING</source>
        <translation>Classification parentale</translation>
    </message>
    <message>
        <source>DATE_PLAYED</source>
        <translation>Date de lecture</translation>
    </message>
    <message>
        <source>DATE_ADDED</source>
        <translation>Date d&apos;ajout</translation>
    </message>
    <message>
        <source>CRITIC_RATING</source>
        <translation>Note des critiques</translation>
    </message>
    <message>
        <source>IMDB_RATING</source>
        <translation>Classement IMDb</translation>
    </message>
    <message>
        <source>Delete Saved</source>
        <translation>Supprimer les informations enregistrées</translation>
    </message>
    <message>
        <source>Save Credentials?</source>
        <translation>Enregistrer les identifiants&#xa0;?</translation>
    </message>
</context>
</TS>
